package prim1.strategy;

public interface NotificationStrategy {
    public void notifyUser(User user, String message);
}
