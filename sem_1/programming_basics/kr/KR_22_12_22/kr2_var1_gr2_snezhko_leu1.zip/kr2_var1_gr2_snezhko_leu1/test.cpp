#include "pch.h"

TEST(TestCaseSum, TestSum) {
  EXPECT_EQ(1, 1);
  EXPECT_TRUE(true);
}