package lab9;

public interface IterableSet<T> {
    Iterator<T> createIterator();
}
