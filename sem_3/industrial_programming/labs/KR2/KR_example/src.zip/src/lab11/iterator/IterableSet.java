package lab11.iterator;

public interface IterableSet<T> {
    Iterator<T> createIterator();
}
