package control_work.cw.kr2.visitor;


import control_work.cw.kr2.mvc.Set;

public interface Visitor {
    void visitSet(Set e);
}
