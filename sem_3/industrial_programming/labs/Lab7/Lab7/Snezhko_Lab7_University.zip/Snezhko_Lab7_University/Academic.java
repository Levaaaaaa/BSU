public class Academic extends Person{
    public Academic(String name) {
        super(name);
    }
}
