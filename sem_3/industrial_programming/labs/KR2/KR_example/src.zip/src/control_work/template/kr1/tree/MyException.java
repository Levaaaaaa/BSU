package control_work.template.kr1.tree;

public class MyException extends Exception {
    public MyException(String str) {
        super(str);
    }
}
