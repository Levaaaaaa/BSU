package visitor;

public interface MyVisitable {
    public int acceptMyVisitor(MyVisitor v);
}
