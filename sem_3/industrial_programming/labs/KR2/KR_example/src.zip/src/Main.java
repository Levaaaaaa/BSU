public class Main {
    public static void main(String[] args) {
        lab12.app.Application.create();
    }
}