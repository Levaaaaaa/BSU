insert into usp_17 (UNUM, OCENKA, SNUM, UDATE, PNUM)
values
(1006, 2, 3400, cast('1999-06-12T00:00:00' AS smalldatetime), 2006),
(1007, 2, 3401, cast('1999-06-13T00:00:00' AS smalldatetime), 2006),
(1008, 2, 3402, cast('1999-06-14T00:00:00' AS smalldatetime), 2006),
(1009, 2, 3403, cast('1999-06-15T00:00:00' AS smalldatetime), 2006),
(1010, 2, 3404, cast('1999-06-16T00:00:00' AS smalldatetime), 2006),
(1011, 2, 3405, cast('1999-06-17T00:00:00' AS smalldatetime), 2006),
(1012, 2, 3406, cast('1999-06-18T00:00:00' AS smalldatetime), 2006),
(1013, 2, 3407, cast('1999-06-19T00:00:00' AS smalldatetime), 2006),
(1014, 2, 3408, cast('1999-06-20T00:00:00' AS smalldatetime), 2006),
(1015, 2, 3409, cast('1999-06-21T00:00:00' AS smalldatetime), 2006);

