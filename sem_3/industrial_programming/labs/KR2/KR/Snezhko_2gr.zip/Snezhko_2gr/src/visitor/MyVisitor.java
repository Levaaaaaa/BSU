package visitor;

import mvc.MySet;

public interface MyVisitor {
    public int visitMySet(MySet set);
}
