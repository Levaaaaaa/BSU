package control_work.template.kr1.car;

public class EmptyException extends Exception{
    public EmptyException()
    {
        super("Container is empty!");
    }
}
