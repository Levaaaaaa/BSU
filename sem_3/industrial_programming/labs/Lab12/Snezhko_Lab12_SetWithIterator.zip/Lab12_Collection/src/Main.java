import javax.swing.*;
import java.util.HashSet;
import java.util.Set;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        MySet<String> set1 = new MySet<>();
        MySet<String> set2 = new MySet<>();
        MySet<String> setResult = new MySet<>();

        set1.add("s11");
        set1.add("s12");
        set1.add("s13");
        set1.add("s11");

        set2.add("s11");
        set2.add("s22");
        set2.add("s23");
        set2.add("s22");

        System.out.println(set1.toString());
        System.out.println(set2.toString());

        System.out.println(set1.conjunction(set2).toString());
        System.out.println(set2.disjunction(set1).toString());
        System.out.println(set1.xor(set2).toString());

        Frame frame = new Frame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setVisible(true);
    }
}