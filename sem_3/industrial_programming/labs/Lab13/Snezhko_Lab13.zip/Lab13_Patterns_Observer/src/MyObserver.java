import java.awt.event.KeyEvent;

public interface MyObserver {
    public void update(KeyEvent event);
}
