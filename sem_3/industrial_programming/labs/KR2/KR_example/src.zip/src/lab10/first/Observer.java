package lab10.first;

import java.util.EventObject;

public interface Observer {
    void update(EventObject object);
}
