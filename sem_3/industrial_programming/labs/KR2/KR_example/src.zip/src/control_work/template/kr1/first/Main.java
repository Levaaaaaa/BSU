package control_work.template.kr1.first;

public class Main {
    public static void main(String[] args) {
        Window w = new Window("Task");

    }
}