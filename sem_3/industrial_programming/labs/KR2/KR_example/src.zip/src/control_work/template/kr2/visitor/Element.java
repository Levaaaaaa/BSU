package control_work.template.kr2.visitor;

public interface Element {
    void accept(Visitor v);
}
