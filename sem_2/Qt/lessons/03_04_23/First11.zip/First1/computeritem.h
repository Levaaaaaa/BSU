#ifndef COMPUTERITEM_H
#define COMPUTERITEM_H

#include <string>
#include <list>
#include <fstream>
class ComputerItem
{
public:
    ComputerItem() = default;
    ComputerItem(std::string _type, std::string _firm, std::string _model, std::string _parametres, double _price,
                 bool _isInStore):type(_type), firm(_firm), model(_model), parametres(_parametres), price(_price),
        isInStore(_isInStore){};
    ~ComputerItem() = default;
    std::string getType()const {return type;};
    std::string getFirm()const {return firm;};
    std::string getModel()const {return model;};
    std::string getParametres()const {return parametres;};
    double getPrice()const {return price;};
    bool getIsInStore()const {return isInStore;};

    private:
    std::string type;
    std::string firm;
    std::string model;
    std::string parametres;
    double price;
    bool isInStore;
};
std::istream&operator>>(std::istream& in, ComputerItem& item)
{
    std::string t, f, m, par;
    double price;
    bool isIn;
    in >> t >> f >> m >> par >> price >> isIn;
    item=ComputerItem(t, f, m, par, price, isIn);
    return in;
};
void ReadFromFile(std::list<ComputerItem>& itemsList, const std::string& filename)
{
    std::ifstream fin;
    fin.open(filename);
    ComputerItem item;
    while(fin>>item) {
        itemsList.push_back(item);
    }
};
#endif // COMPUTERITEM_H
