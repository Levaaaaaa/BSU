#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_readFile_clicked()
{
    QString line = QFileDialog::getOpenFileName(0, "Open dialog", "", "*.txt");
    ReadFromFile(Items, line.toStdString());
    ShowComputerItems();
}

void MainWindow::ShowComputerItems()
{
    ui->itemsTextEdit->clear();
    for (const auto& item :Items ) {
        //преобразовать в единую строчку QString каждый item
    }
}

