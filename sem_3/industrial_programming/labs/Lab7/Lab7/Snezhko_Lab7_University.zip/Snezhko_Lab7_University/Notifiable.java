public interface Notifiable {
    void notify(String message);
}
