package iterator;

public interface MyIterable<T> {
    public MyIterator<T> iterator();
}
