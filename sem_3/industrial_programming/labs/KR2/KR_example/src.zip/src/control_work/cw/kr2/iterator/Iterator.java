package control_work.cw.kr2.iterator;

public interface Iterator {
    void first();

    void next();

    boolean isDone();

    int currentItem();
}
