import javax.swing.*;
import java.util.ArrayList;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        Frame frame = new Frame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setVisible(true);
        /*
        Employee guard1 = new SecurityGuard("Guard1", "Organization1", 0.3, 2.4);
        Employee guard2 = new SecurityGuard("Guard2", "BOrganization2", 0.5, 2.6);
        Employee guard3 = new SecurityGuard("Guard3", "Organization3", 0.1, 2.2);
        Employee guard4 = new SecurityGuard("Guard4", "BOrganization4", 0.5, 2.8);
        Employee seller1 = new Seller("Seller1", "Organzation1", 0.2, 20);
        Employee seller2 = new Seller("Seller2", "BOrganzation2", 0.3, 30);
        Employee seller3 = new Seller("Seller3", "Organzation3", 0.4, 40);
        ArrayList<Employee> list = new ArrayList<>();
        list.add(guard1);
        list.add(guard2);
        list.add(guard3);
        list.add(guard4);
        list.add(seller1);
        list.add(seller2);
        list.add(seller3);

        ProcessCollection.findOrganizationStartWithB(list).stream().peek(System.out::println);
        System.out.println(ProcessCollection.calculateAverageSalary(list, "Organization3") + "\n");
        ProcessCollection.getListByDecreaseSalary(list).stream().peek(System.out::println);
        ProcessCollection.getListBySalaryAndJobCoeff(list).stream().peek(System.out::println);

        */
    }
}