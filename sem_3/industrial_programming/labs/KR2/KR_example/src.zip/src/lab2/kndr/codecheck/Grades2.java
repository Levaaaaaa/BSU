package lab2.kndr.codecheck;

public class Grades2 {

}
