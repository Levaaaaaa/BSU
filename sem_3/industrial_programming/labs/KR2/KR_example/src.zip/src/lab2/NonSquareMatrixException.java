package lab2;

public class NonSquareMatrixException extends IllegalArgumentException {
    NonSquareMatrixException(String message) { super(message); }
}
