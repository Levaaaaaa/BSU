package lab1;

public class EmptyStringException extends IllegalArgumentException {
    public EmptyStringException(String message) {
        super(message);
    }
}
