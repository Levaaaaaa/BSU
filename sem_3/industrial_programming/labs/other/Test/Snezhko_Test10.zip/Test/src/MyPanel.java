import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class MyPanel extends JPanel implements MouseListener {
    private ArrayList<MyPair<Point, Color>> points = new ArrayList<>();
    private Color propertyColor;
    public MyPanel() {
        super();
    }
    public MyPanel(Color color) {
        super();
        this.propertyColor = color;
    }
    @Override
    public void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        graphics.setColor(propertyColor);
        graphics.drawOval(0, 0, 100, 100);//this.getX(), this.getY(), this.getWidth(), this.getHeight());
        points.forEach(point -> {
            graphics.setColor(point.getSecond());
            graphics.drawOval(point.getFirst().x, point.getFirst().y, 1,1);
        });
        addMouseListener(this);
    }
    @Override
    public void mouseClicked(MouseEvent event) {
        points.add(new MyPair<>(event.getPoint(), Color.RED));
        this.repaint();
    }
    @Override
    public void mousePressed(MouseEvent event) {
        points.add(new MyPair<>(event.getPoint(), Color.RED));
        this.repaint();
    }
    @Override
    public void mouseReleased(MouseEvent event) {
        points.add(new MyPair<>(event.getPoint(), Color.RED));
        this.repaint();
    }
    @Override
    public void mouseEntered(MouseEvent event) {
        points.add(new MyPair<>(event.getPoint(), Color.RED));
        this.repaint();
    }
    @Override
    public void mouseExited(MouseEvent event) {
        points.add(new MyPair<>(event.getPoint(), Color.RED));
        this.repaint();
    }
}
