package prim1.observer;

public interface MyObserver {
    public void update(MySubject theChangedSubject);
}
