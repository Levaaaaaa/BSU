#include "computeritem.h"

ComputerItem::ComputerItem()
{

}
