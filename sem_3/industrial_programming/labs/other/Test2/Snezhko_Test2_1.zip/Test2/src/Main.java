// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        StudentLinkedList list = new StudentLinkedList(new Student("student1"));
        list.add(new Student("student2"));
        list.add(new Student("student3"));
        list.print();
    }
}