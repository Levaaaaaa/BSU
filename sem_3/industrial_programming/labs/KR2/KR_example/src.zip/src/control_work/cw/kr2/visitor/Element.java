package control_work.cw.kr2.visitor;

public interface Element {
    void accept(Visitor v);
}
