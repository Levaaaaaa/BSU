package control_work.cw.kr2.strategy;

import control_work.cw.kr2.mvc.Set;

public interface Strategy {
    int cardinality(Set element);
}
