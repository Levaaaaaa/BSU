public interface StudentList {
    void add(Student student);
    void delete(Student name);
    void print();
}
