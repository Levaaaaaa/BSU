public class StudentLinkedList implements StudentList{
    private StudentNode head;

    public StudentLinkedList(Student head) {
        this.head = new StudentNode(head, null);
    }

    public StudentNode getHead() {
        return head;
    }

    public void setHead(StudentNode head) {
        this.head = head;
    }
    private class StudentNode {
        Student data;
        StudentNode next;

        public StudentNode(Student data, StudentNode next) {
            this.data = data;
            this.next = next;
        }

        public Student getData() {
            return data;
        }

        public StudentNode getNext() {
            return next;
        }

        public void setData(Student data) {
            this.data = data;
        }

        public void setNext(StudentNode next) {
            this.next = next;
        }
    }

    @Override
    public void add(Student student) {
        StudentNode newNode = new StudentNode(student, head);
        head = newNode;
    }

    @Override
    public void delete(Student name) {

    }

    @Override
    public void print() {
        StudentNode curNode = head;
        while(curNode.getNext() != null) {
            System.out.println(curNode.getData());
            curNode = curNode.next;
        }
        System.out.println(curNode.getData());
    }
}
