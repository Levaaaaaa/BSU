package control_work.cw.kr1.src;

public class Main {
    public static void main(String[] args) {
        new Application();
    }
}
