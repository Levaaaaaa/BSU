package control_work.template.kr2.iterator;

public interface IterableCollection<T> {
    Iterator<T> createIterator();
}
