package strategy;

import mvc.MySet;

public interface CalculateCardinalityStrategy {
    public int calculateCardinality(MySet set);
}
