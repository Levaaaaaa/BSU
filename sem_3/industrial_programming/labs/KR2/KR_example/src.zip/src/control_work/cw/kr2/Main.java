package control_work.cw.kr2;

public class Main {
    public static void main(String[] args) {
        App.create();
        // M - Set (пассивная модель)
        // V - view
        // C - Controller
        // all in package mvc
    }
}