import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class MyPanel extends JPanel implements MouseListener {
    private ArrayList<MyPair<Point, Color>> points = new ArrayList<>();
    private Color propertyColor;
    public MyPanel() {
        super();
    }
    public MyPanel(Color color) {
        super();
        this.propertyColor = color;
    }
    @Override
    public void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Rectangle rectangle = new Rectangle(this.getWidth(), this.getHeight());
        graphics.drawOval(0, 0, 100, 100);//this.getX(), this.getY(), this.getWidth(), this.getHeight());
        graphics.setColor(propertyColor);
        
    }
    @Override
    public void mouseClicked(MouseEvent event) {
        points.add(new MyPair<>(event.getPoint(), Color.RED));
        this.repaint();
    }
    @Override
    public void mousePressed(MouseEvent event) {
        return;
    }
    @Override
    public void mouseReleased(MouseEvent event) {
        return;
    }
    @Override
    public void mouseEntered(MouseEvent event) {
        return;
    }
    @Override
    public void mouseExited(MouseEvent event) {
        return;
    }
}
