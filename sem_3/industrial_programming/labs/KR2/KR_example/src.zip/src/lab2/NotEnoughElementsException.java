package lab2;

public class NotEnoughElementsException extends NonSquareMatrixException {
    NotEnoughElementsException(String message) {
        super(message);
    }
}
