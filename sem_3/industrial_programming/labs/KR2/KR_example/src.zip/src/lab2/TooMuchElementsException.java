package lab2;

public class TooMuchElementsException extends NonSquareMatrixException {
    TooMuchElementsException(String message) { super(message); }
}
