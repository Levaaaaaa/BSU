package control_work.cw.kr2.iterator;

public interface IterableCollection {
    Iterator createIterator();
}
