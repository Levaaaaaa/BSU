import javax.swing.*;
import java.awt.*;

public class MyFrame extends JFrame {
    private MyPanel panel1 = new MyPanel();
    private MyPanel panel2 = new MyPanel();
    GridLayout layout = new GridLayout(2,1);
    public MyFrame() {
        super("My Frame");
        layout.addLayoutComponent("Panel1", panel1);
        layout.addLayoutComponent("Panel2", panel2);
        setLayout(layout);
        panel1.setVisible(true);
        panel1.repaint();//new Rectangle(0, 0, 50, 50));
        panel2.repaint();
    }
}
